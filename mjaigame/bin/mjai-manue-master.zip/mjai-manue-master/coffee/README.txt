$ sudo npm install -g coffee-script
$ coffee main.coffee
