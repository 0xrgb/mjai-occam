class MjaiComponentLeaf

  def initialize; end

  def hello(action); end

  def start_game(action); end

  def tsumo(action); end
  
  def start_kyoku(action); end

  def dahai(action); end

  def reach(action); end

  def reach_accepted(action); end

  def pon(action); end

  def chi(action); end

  def ankan(action); end

  def daiminkan(action); end
  
  def kakan(action); end

  def dora(action); end

  def hora(action); end

  def ryukyoku(action); end

  def end_kyoku(action); end
  
  def end_game(action); end

end
